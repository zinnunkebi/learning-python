\set ECHO queries
\i .\makedml.sql
\q
